.. oss_project documentation master file, created by
   sphinx-quickstart on Wed Dec  4 22:58:41 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Overview
========

oss_project is a python project. 
This is the pymood package available in pyhon.
The pymood package analyzes emotions based on text input. 
And you can also talk to chatbots.


oss_project documentation
=========================
.. toctree::

   usage

