Useage
======

Installation
------------
blah blah


Creating recipes
----------------

To analyze the emotion contained in a sentence in English,
you can use ``pymood.anlaysis_emotion()`` function
This function analyzes the mood of sentences collected in English and 
returns emoticons that fit the situation.

.. autofunction:: pymood.analysis_emotion 



